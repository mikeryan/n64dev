Title: The Legend of Zelda: Ocarina of Time
Save Type: SRAM
Format: .RAM
Size: 256Kbits (32Kbytes)
Features: All item - Gold Skultulla - Heart - Magic .....ALL !
Created by: Mimik
Hacked: Unknown