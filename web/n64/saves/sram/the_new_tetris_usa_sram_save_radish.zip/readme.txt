Title: The New Tetris
Save Type: SRAM
Format: .RAM
Size: 256Kbits (32Kbytes)
Features: All Buildings Completed, Finale Open for viewing.
Created by: Radish
Hacked: Unknown