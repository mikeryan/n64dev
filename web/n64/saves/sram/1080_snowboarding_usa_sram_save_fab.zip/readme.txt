Title: 1080 Degrees Snowboarding
Save Type: SRAM
Format: .RAM
Size: 256Kbits (32Kbytes)
Features: All match races completed, all tracks open.
Created by: fab
Hacked: Yes