Title: Super Mario 64
Save Type: EEPROM
Format: .SAV
Size: 4Kbits (512 bytes)
Features: All 120 stars obtained.
Created by: Unknown
Hacked: Unknown